/*
 * Boton Usuario
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author pablo
 */
public class BtnUser extends Btn{
    
    public BtnUser(){
        setText("Usuario");
        setIcon(iconos.getUser(16));
    }
    
}
