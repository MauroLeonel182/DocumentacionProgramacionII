/*
 * Boton Salir
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author pablo
 */
public class BtnUpdate extends Btn{
    
    public BtnUpdate(){
        setText("Actualizar");
        setIcon(iconos.getUpdate(16));
    }
    
}
