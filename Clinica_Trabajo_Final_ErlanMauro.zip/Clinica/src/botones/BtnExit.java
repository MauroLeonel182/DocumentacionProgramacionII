/*
 * Boton Salir
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author pablo
 */
public class BtnExit extends Btn{
    
    public BtnExit(){
        setText("Salir");
        setIcon(iconos.getExit(16));
    }
    
}
