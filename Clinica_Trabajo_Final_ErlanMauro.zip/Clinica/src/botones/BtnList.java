/*
 * Boton Lista
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author pablo
 */
public class BtnList extends Btn{
    
    public BtnList(){
        setText("Lista");
        setIcon(iconos.getList(16));
    }
    
}
