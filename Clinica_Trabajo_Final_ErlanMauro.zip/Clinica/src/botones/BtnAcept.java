/*
 * Boton Filtro
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author pablo
 */
public class BtnAcept extends Btn{
    
    public BtnAcept(){
        setText("Aceptar");
        setIcon(iconos.getAcept(16));
    }
    
}
