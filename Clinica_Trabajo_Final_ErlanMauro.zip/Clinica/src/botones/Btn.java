/*
 * Clase base o super clase para la creacion de los botones
 */
package botones;
import javax.swing.JButton;

/**
 *
 * @author Leo
 */

public class Btn extends JButton{
    
    public Btn (){
        setFont(new java.awt.Font("Thaoma",1 ,10));
    }
}
