/*
 * Boton Filtro
 */
package botones;

import static clinica.FrmSistema.iconos;


/**
 *
 * @author pablo
 */
public class BtnFilter extends Btn{
    
    public BtnFilter(){
        setText("Filtro");
        setIcon(iconos.getFilter(16));
    }
    
}
