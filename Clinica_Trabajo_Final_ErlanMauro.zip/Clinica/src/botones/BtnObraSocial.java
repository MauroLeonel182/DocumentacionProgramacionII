/*
 * Boton Localidad
 */
package botones;

import static clinica.FrmSistema.iconos;

/**
 *
 * @author pablo
 */
public class BtnObraSocial extends Btn{
    
    public BtnObraSocial(){
        setText("Localidad");
        setIcon(iconos.getObraSocial(16));
    }
    
}
