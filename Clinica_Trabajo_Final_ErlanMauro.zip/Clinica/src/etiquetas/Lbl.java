/*
 * SUPERCLASE PARA ETIQUETAS O JLabel
 */
package etiquetas;

import javax.swing.JLabel;

/**
 *
 * @author Leo
 */
public class Lbl extends JLabel{
    
    public Lbl(){
        setText("");
    }
    
}
