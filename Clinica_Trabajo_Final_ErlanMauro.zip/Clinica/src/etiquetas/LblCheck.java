/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package etiquetas;

import static clinica.FrmSistema.iconos;

/**
 *
 * @author Leo
 */
public class LblCheck extends Lbl{
    
    public LblCheck(){
        setText("Oblicatorio:");
        setIcon(iconos.getCheck(16));
    }
}
